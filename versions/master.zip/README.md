# Objekt Oriteret Programmering med PDO

## Forord
I dette projekt, gennemgår vi OOP med PDO for begyndere. <br>
Vi laver forskellige moduler indefor forskellige niveauer.<br>
Du kan se på denne liste, hvor langt vi er kommet,<br>
samt hvad de forskellige moduler er kategoriseret i niveau.

## Basic:
## Indeholder:
1) Dynamisk Menu
2) Switch case på index
3) Logind side
4) Bruger oprettelse

## Øvet
## Indeholder:
1) Kontakt formular
2) Produkter
3) Produkt Søgning
4) Opret, Rediger og slet produkt
5) Rediger og slet bruger


## Avanceret 
## Indeholder:
1) Kommer snart!


## Professional
## Indeholder:
1) Kommer snart! 

###### Kode fra [Marc Carpens](https://github.com/Mcarpens "Marc Carpens") & [Mikkel Olsen](https://github.com/MikkelOlsen "Mikkel Olsen")
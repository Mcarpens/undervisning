<div class="usrp-fb-2 slide-in">
    <div class="usrp-fb-state-collapsed">
        <div class="usrp-fb-title"> &nbsp; DEBUG &nbsp;</div>
    </div>

    <div class="usrp-fb-state-expanded">
        <div class="usrp-fb-title"><i class="fa fa-bug"></i> DEBUG MENU <i class="fa fa-bug"></i></div>
        <?php print_r($_SESSION) ?>
        <div class="usrp-fb-divider"></div>
        <form method="post">
            <button type="submit" class="usrp-fb-btn usrp-fb-btn-yes" name="hide">SKJUL</button>
        </form>
    </div>
</div>

<?php
/**
 * Created by PhpStorm.
 * User: mcarp
 * Date: 19-01-2018
 * Time: 10:20
 */

$notification->deleteAllNotifications();
$user->redirect('notifikationer');